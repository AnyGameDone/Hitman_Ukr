#include "common.fx"

struct a2vSprite {
	float4	v4Position:	POSITION;
	float4	v4Diffuse:	COLOR0;
	float2	vTexCoords:	TEXCOORD0;
};

// Fragment to surface
struct f2sSprite {
	float4 col:		COLOR0;
};

bool gi_AlphaBlendEnabled=false;
int gi_BlendSrc=1;
int	gi_BlendDst=1;
bool gi_AlphaTestEnabled=false;
int	gi_AlphaTestValue=0;
int gi_iZBufferFunc=4; // LessEqual


void CalculateFogSprites(out float vFogOut, float fDistance) {
	vFogOut=-fDistance*vFogSettings.y+vFogSettings.x; // compiles into a single mad instruction
}


//////////////////////////////////////////////////////////////////
/// Ambient layer
//////////////////////////////////////////////////////////////////
struct v2fSpriteAmbient2 {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
	float2 TexDiffuse2:	TEXCOORD1;
	float Fog:			FOG;
};

// Vertex shader
v2fSpriteAmbient2 Ambient_Sprites_VS11(a2vSprite IN)
{
	v2fSpriteAmbient2 OUT;
	
	//float4 Position=mul(m44ModelViewProj,IN.v4Position);
	float4 Position=mul(IN.v4Position, m44Proj);
	OUT.Position=Position;
	OUT.TexDiffuse=IN.vTexCoords;
	OUT.TexDiffuse2=IN.vTexCoords;
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a;
	
	CalculateFogSprites(OUT.Fog,IN.v4Position.z);
	
	return OUT;
}

// Pixel shader
f2sSprite Ambient_Mask_PS11(v2fSpriteAmbient2 IN) 
{
	f2sSprite OUT;
	
	float4 cTexel;
	cTexel.rgb=tex2D(samplerDiffuse,IN.TexDiffuse.xy).rgb;
	cTexel.a=tex2D(samplerDiffuseMask,IN.TexDiffuse2.xy).a;
	//cTexel=tex2D(samplerDiffuse,IN.TexDiffuse2.xy);
	//cTexel=tex2D(samplerDiffuseMask,IN.TexDiffuse2.xy);
	OUT.col=IN.Diffuse*cTexel*2;
	
	return OUT;
}

// Techniques
technique Ambient_Sprites_VS11_PS11 < string Identifier="AmbientSprites"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_Sprites_VS11();
		PixelShader=compile ps_1_1 Ambient_Mask_PS11();
		
		AlphaBlendEnable=<gi_AlphaBlendEnabled>;
		SrcBlend=<gi_BlendSrc>;
		DestBlend=<gi_BlendDst>;
		AlphaTestEnable=<gi_AlphaTestEnabled>;
		AlphaRef=<gi_AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=<gi_iZBufferFunc>;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
struct v2fSpriteAmbient {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
	float Fog:			FOG;
};

struct a2vSpriteSnow {
	float4	v4Position:	POSITION;
	float	v4Attrs:	BLENDWEIGHT; //x=scale
	float3	vTexCoords:	BLENDINDICES;
};

float gi_vSpriteBoxFar;
float4 gi_vSpriteBoxColor;
float4 gi_vSpriteBoxPositions[8];
float4 gi_vSpriteBoxAspect;

// Pixel shader
f2sSprite Ambient_PS11(v2fSpriteAmbient IN) 
{
	f2sSprite OUT;
	
	float4 cTexel;
	cTexel=tex2D(samplerDiffuse,IN.TexDiffuse.xy);
	OUT.col=2*IN.Diffuse*cTexel;
	
	return OUT;
}

// Vertex shader
v2fSpriteAmbient Ambient_SpritesSnow_VS11(a2vSpriteSnow IN)
{
	v2fSpriteAmbient OUT;
	
	float4 v4DirectionBot0=gi_vSpriteBoxPositions[0];
	float4 v4DirectionBot1=gi_vSpriteBoxPositions[1];
	float4 v4DirectionTop0=gi_vSpriteBoxPositions[2];
	float4 v4DirectionTop1=gi_vSpriteBoxPositions[3];
	float4 v4CornerBot0=gi_vSpriteBoxPositions[4];
	float4 v4CornerBot1=gi_vSpriteBoxPositions[5];
	float4 v4CornerTop0=gi_vSpriteBoxPositions[6];
	float4 v4CornerTop1=gi_vSpriteBoxPositions[7];
	float4 v4Color=gi_vSpriteBoxColor;
	float v4BoxFar=gi_vSpriteBoxFar;
	float4 v4Aspect=gi_vSpriteBoxAspect;

	float3 p0,p1,p2,p3;

	float4 v4Constants=float4(1.0f,0.5f,0.0f,256.0f/16.0f);

	p0=IN.v4Position.xyz;
	p1=v4DirectionBot0.xyz*p0.x;
	p3=v4DirectionBot1.xyz*p0.x;
	p1+=v4CornerBot0.xyz;
	p3+=v4CornerBot1.xyz;
	p3-=p1;
	p3*=p0.z;
	p1+=p3;

	p2=v4DirectionTop0.xyz*p0.x;
	p3=v4DirectionTop1.xyz*p0.x;
	p2+=v4CornerTop0.xyz;
	p3+=v4CornerTop1.xyz;
	p3-=p2;
	p3*=p0.z;
	p2+=p3;

	float4 p;
	p2-=p1;
	p2*=p0.y;
	p.xyz=p1+p2;
	p.w=v4Constants.x;

	// Transformed position
	float4 v4PositionT=mul(p, m44ModelViewProj);
	// We do not touch the w component - So size reduction with depth is automatic
	float4 billboard;
	billboard=(IN.vTexCoords.xyzz-v4Constants.yyzz)*(IN.v4Attrs.xxxx);
	OUT.Position=v4PositionT+billboard*v4Constants.xxzz*v4Aspect;
	
	OUT.TexDiffuse.x=IN.vTexCoords.z;
	OUT.TexDiffuse.y=v4Constants.x-IN.vTexCoords.y;
	// Fade particles
	float fMin=v4BoxFar.x*0.9;
	float fMax=v4BoxFar.x;
	float fIntensity=(fMax-v4PositionT.z)/(fMax-fMin);
	OUT.Diffuse=v4Color*saturate(fIntensity);
	CalculateFog(OUT.Fog,p);

	return OUT;
}

// Techniques
technique Ambient_SpritesSnow_VS11_PS11 < string Identifier="AmbientSpritesSnow"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_SpritesSnow_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		AlphaBlendEnable=<gi_AlphaBlendEnabled>;
		SrcBlend=<gi_BlendSrc>;
		DestBlend=<gi_BlendDst>;
		AlphaTestEnable=<gi_AlphaTestEnabled>;
		AlphaRef=<gi_AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=<gi_iZBufferFunc>;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
struct a2vSpriteRain {
	float4	v4Position:	POSITION;
	float4	v4Attrs:	BLENDWEIGHT; // x,y,z=direction vector, w=scale
	float3	vTexCoords:	BLENDINDICES;
};

// Vertex shader
v2fSpriteAmbient Ambient_SpritesRain_VS11(a2vSpriteRain IN)
{
	v2fSpriteAmbient OUT;
	
	float4 v4DirectionBot0=gi_vSpriteBoxPositions[0];
	float4 v4DirectionBot1=gi_vSpriteBoxPositions[1];
	float4 v4DirectionTop0=gi_vSpriteBoxPositions[2];
	float4 v4DirectionTop1=gi_vSpriteBoxPositions[3];
	float4 v4CornerBot0=gi_vSpriteBoxPositions[4];
	float4 v4CornerBot1=gi_vSpriteBoxPositions[5];
	float4 v4CornerTop0=gi_vSpriteBoxPositions[6];
	float4 v4CornerTop1=gi_vSpriteBoxPositions[7];
	float4 v4Color=gi_vSpriteBoxColor;
	float v4BoxFar=gi_vSpriteBoxFar;
	float4 v4Aspect=gi_vSpriteBoxAspect;

	float3 p0,p1,p2,p3;

	float4 v4Constants=float4(1.0f,0.5f,0.0f,255.0);

	p0=IN.v4Position.xyz;
	p1=v4DirectionBot0.xyz*p0.x;
	p3=v4DirectionBot1.xyz*p0.x;
	p1+=v4CornerBot0.xyz;
	p3+=v4CornerBot1.xyz;
	p3-=p1;
	p3*=p0.z;
	p1+=p3;

	p2=v4DirectionTop0.xyz*p0.x;
	p3=v4DirectionTop1.xyz*p0.x;
	p2+=v4CornerTop0.xyz;
	p3+=v4CornerTop1.xyz;
	p3-=p2;
	p3*=p0.z;
	p2+=p3;

	p2-=p1;
	p2*=p0.y;
	p0=p1+p2;

	// Calculate direction vector
	float3 v0;
	v0=IN.v4Position.xyz+IN.v4Attrs.xyz;
	p1=v4DirectionBot0.xyz*v0.x;
	p3=v4DirectionBot1.xyz*v0.x;
	p1+=v4CornerBot0.xyz;
	p3+=v4CornerBot1.xyz;
	p3-=p1;
	p3*=v0.z;
	p1+=p3;

	p2=v4DirectionTop0.xyz*v0.x;
	p3=v4DirectionTop1.xyz*v0.x;
	p2+=v4CornerTop0.xyz;
	p3+=v4CornerTop1.xyz;
	p3-=p2;
	p3*=v0.z;
	p2+=p3;

	p2-=p1;
	p2*=v0.y;
	v0=p2+p1;
	v0-=p0;

	float4 temp;
	// Transformed position
	temp.xyz=p0;
	temp.w=v4Constants.x;
	p0.x=dot(m44ModelView[0],temp);
	p0.y=dot(m44ModelView[1],temp);
	p0.z=dot(m44ModelView[2],temp);
	// Transformed direction
	temp.xyz=v0;
	v0.x=dot(m44ModelView[0].xyz,temp.xyz);
	v0.y=dot(m44ModelView[1].xyz,temp.xyz);
	v0.z=dot(m44ModelView[2].xyz,temp.xyz);

	float3 v1,v2;
	v1=v0;
	v2=cross(p0,v0);
	v2=normalize(v2);
	v2*=IN.v4Attrs.w;

	float3 va=(IN.vTexCoords.x-v4Constants.y)*v1;
	float3 vb=(IN.vTexCoords.y-v4Constants.y)*v2;
	p0+=va+vb;

	// Project output
	float4 pp;
	pp.xyz=p0;
	pp.w=IN.v4Position.w;
	float4 v4PositionT=mul(pp, m44Proj);

	v4Aspect.zw=1;
	OUT.Position=v4PositionT*v4Aspect;
	CalculateFogSprites(OUT.Fog,pp.z);
	OUT.TexDiffuse=IN.vTexCoords.zy;
	float fMin=v4BoxFar.x*0.9;
	float fMax=v4BoxFar.x;
	float fIntensity=(fMax-v4PositionT.z)/(fMax-fMin);
	OUT.Diffuse=v4Color*saturate(fIntensity);

	return OUT;
}

// Techniques
technique Ambient_SpritesRain_VS11_PS11 < string Identifier="AmbientSpritesRain"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 Ambient_SpritesRain_VS11();
		PixelShader=compile ps_1_1 Ambient_PS11();
		
		AlphaBlendEnable=<gi_AlphaBlendEnabled>;
		SrcBlend=<gi_BlendSrc>;
		DestBlend=<gi_BlendDst>;
		AlphaTestEnable=<gi_AlphaTestEnabled>;
		AlphaRef=<gi_AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=<gi_iZBufferFunc>;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
