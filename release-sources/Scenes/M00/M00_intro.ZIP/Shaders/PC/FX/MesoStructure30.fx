#include "StandardCommon.fx"

#line 4 "MesoStructure30.fx"

struct a2vMesoHQ {
	float4	v4Position:		POSITION;
	float3	v3Normal:		NORMAL;
	float4	vLightCol:		COLOR0; 
	float3	vTexCoords:		TEXCOORD0;
	float3	v3Tangent:		TANGENT;
	float3	v3Binormal:		BINORMAL;
	float2  vParallax:		TEXCOORD1;
	float4	vPlane0:		BLENDWEIGHT0;
	float4	vPlane1:		BLENDWEIGHT1;
	float4	vPlane2:		BLENDWEIGHT2;
	float4	vPlane3:		BLENDWEIGHT3;
	float4	vPlane4:		BLENDWEIGHT4;
	//float4	vPlane5:		BLENDWEIGHT5;
	//float4	vPlane6:		BLENDWEIGHT6;
	//float4	vPlane7:		BLENDWEIGHT7;
};


//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 vTexCoords:		TEXCOORD0;
	float4 vEyeDirTS:		TEXCOORD1;
	float4 vPlane1:			TEXCOORD2;
	float4 vPlane2:			TEXCOORD3;
	float4 vPlane3:			TEXCOORD4;
	float4 vPlane4:			TEXCOORD5;
	//float4 vPlane5:			TEXCOORD6;
	float3 vEyeDirOS:		TEXCOORD6;
	float4 vPosition:		TEXCOORD7;
};

v2fStandardAmbientHQ20 MesoHQ_VS20(a2vMesoHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	float4 OPOS = IN.v4Position;
	float3 ONOR = IN.v3Normal;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(ONOR));
	
	//float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	//OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	OUT.vEyeDirTS.xyz=mul(m33TangentSpace,vEyeDirOS);

	OUT.vEyeDirOS=vEyeDirOS;
	OUT.vPosition=IN.v4Position;
	
	OUT.vPlane1=IN.vPlane0; // Top
	OUT.vPlane2=IN.vPlane1; // Bot
	OUT.vPlane3=IN.vPlane2; // Fin1a
	OUT.vPlane4=IN.vPlane3; // Fin2a
	//OUT.vPlane5=IN.vPlane6; // Fin3a
		
	OUT.vTexCoords.xyz=IN.vTexCoords;
#ifdef PARALLAXENABLED
	float2 vParallax=4.0/IN.vParallax;
	OUT.vTexCoords.w=vParallax.x;
	OUT.vEyeDirTS.w=vParallax.y;
#endif
	
	CalcPosition(OUT.Position,OPOS);
	
	return OUT;
}

f2sStandard MesoHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	
	float fDist=1000;
	float3 vEyeDirOS=normalize(IN.vEyeDirOS);
	float fDist1=dot(IN.vPlane1,IN.vPosition)/dot(IN.vPlane1.xyz,vEyeDirOS);
	float fDist2=dot(IN.vPlane2,IN.vPosition)/dot(IN.vPlane2.xyz,vEyeDirOS);
	float fDist3=dot(IN.vPlane3,IN.vPosition)/dot(IN.vPlane3.xyz,vEyeDirOS);
	float fDist4=dot(IN.vPlane4,IN.vPosition)/dot(IN.vPlane4.xyz,vEyeDirOS);
	//float fDist5=dot(IN.vPlane5,IN.vPosition)/dot(IN.vPlane5.xyz,vEyeDirOS);
	if(dot(IN.vPlane1.xyz,vEyeDirOS)<0 && fDist1<fDist) fDist=fDist1;
	if(dot(IN.vPlane2.xyz,vEyeDirOS)<0 && fDist2<fDist) fDist=fDist2;
	if(dot(IN.vPlane3.xyz,vEyeDirOS)<0 && fDist3<fDist) fDist=fDist3;
	if(dot(IN.vPlane4.xyz,vEyeDirOS)<0 && fDist4<fDist) fDist=fDist4;
	//if(dot(IN.vPlane5.xyz,vEyeDirOS)<0 && fDist5<fDist) fDist=fDist5;
	//if(fDist==1000) clip(-1);
	
	static const int lNumSamples=16;
	static const float fParallaxScale=30;
	
	float3 vScaling=float3(IN.vTexCoords.w,IN.vEyeDirTS.w,1);
	float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	vEyeDirTS*=-vScaling;
	
	float3 vEnter=IN.vTexCoords;
	float3 vLeave=vEnter+vEyeDirTS*fDist;
	float3 vDt=(vLeave-vEnter)/(lNumSamples-1);
	
	bool bSampleFound=false;
	float3 vBestSample=vLeave;
	float3 vSample=vLeave;
	float fHeight=tex2D(samplerParallax,vSample).r*fParallaxScale;
	float fDiff2=vSample.z-fHeight;
	for(int i=0; i<lNumSamples; i++) {
		vSample-=vDt;
		fHeight=tex2D(samplerParallax,vSample).r*fParallaxScale;
		float fDiff1=vSample.z-fHeight;
		/*if(fDiff1>0 && fDiff2<0) {
			vBestSample=vSample+vDt*fDiff1/(fDiff1-fDiff2);
			bSampleFound=true;
		}*/
		float fLerp=(max(fDiff1,0)*max(-fDiff2,0))>0;
		vBestSample=lerp(vBestSample,vSample+vDt*fDiff1/(fDiff1-fDiff2),fLerp);
		fDiff2=fDiff1;
	}
	
	if(vBestSample.z==vLeave.z && vBestSample.x==vLeave.x)
	//if(!bSampleFound) 
	{
		clip(-1);
	} else {
		float3 v3BumpNormal=CalculateBumpNormalPS(vBestSample);
		float4 cTexel=tex2D(samplerDiffuse,vBestSample);
		OUT.col=cTexel*(0.5+0.5*dot(v3BumpNormal,normalize(IN.vEyeDirTS)));
	}
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_3_0 MesoHQ_VS20();
		PixelShader=compile ps_3_0 MesoHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=false;
		FogColor=<vFogColor>;
	}
}
#endif
