#include "common.fx"

// Application to Vertex defined by material class
struct a2vStandard {
	float4	v4Position:		POSITION0;
	float3	v3Normal:		NORMAL0;
	float4	vLightCol:		COLOR0; // Light color * vertex color
	float4	vVertexCol:		COLOR1; // Original vertex color
	float2	vTexCoords:		TEXCOORD0;
	float3	v3Tangent:		TANGENT0;
	float3	v3Binormal:		BINORMAL0;
#ifdef MESH_TWEENED
	float4	v4Position2:	POSITION1;
	float3	v3Normal2:		NORMAL1;
	float4	vLightCol2:		COLOR2;
	float4	vVertexCol2:	COLOR3; // Original vertex color
	float3	v3Tangent2:		TANGENT1;
	float3	v3Binormal2:	BINORMAL1;
#endif
};

struct a2vStandardHQ {
	float4	v4Position:		POSITION;
	float3	v3Normal:		NORMAL;
	float4	vLightCol:		COLOR0; // Light color * vertex color
	float4	vLightDir:		COLOR1; // Light direction
	float4	v4Ambient:		COLOR2; // Ambient color
	float4	vVertexCol:		COLOR3; // Original vertex color
	float2	vTexCoords:		TEXCOORD0;
	float3	v3Tangent:		TANGENT;
	float3	v3Binormal:		BINORMAL;
	float2  vParallax:		TEXCOORD1; // Scale of tangent and binormal vectors
#ifdef MESH_TWEENED
	float4	v4Position2:	POSITION1;
	float3	v3Normal2:		NORMAL1;
	float4	vLightCol2:		COLOR4; // Light color * vertex color
	float4	vLightDir2:		COLOR5; // Light direction
	//float4	v4Ambient2:		COLOR6; // Ambient color
	float4	vVertexCol2:	COLOR7; // Original vertex color
	float3	v3Tangent2:		TANGENT1;
	float3	v3Binormal2:	BINORMAL1;
#endif
};

struct a2vStandardRigid {
	float4	v4Position:		POSITION0;
	float3	v3Normal:		NORMAL0;
	float4	vVertexCol:		COLOR0;			// Original vertex color
	float2	vTexCoords:		TEXCOORD0;
	float3	v3Tangent:		TANGENT0;
	float3	v3Binormal:		BINORMAL0;
	float2  vParallax:		TEXCOORD1;		// Scale of tangent and binormal vectors
};

struct a2vStandardMPS {
	float4	v4Position:	POSITION;
	float4	v4Weights:	BLENDWEIGHT;
	int4	v4Indices:	BLENDINDICES;
	float3	v3Normal:	NORMAL;
	float4	v4Diffuse:	COLOR0;
	float2	vTexCoords:	TEXCOORD0;
	float3	v3Tangent:	TANGENT;
	float3	v3Binormal:	BINORMAL;
};

// Fragment to surface
struct f2sStandard {
	float4 col:		COLOR0;
};

