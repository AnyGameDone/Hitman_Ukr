#include "standardcommon.fx"
/*
	Description:
		cloth shader 
		this is based on the skin shader, it only does not support subsurface scattering
	Features:
		* PerPixel lighting with rim lighting 
		* Support for skinned models
	Author:
		Mircea Marghidanu
*/

//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:	TEXCOORD0;
	float3 vLightDirTS:		TEXCOORD1;
	float3 vEyeDirTS:		TEXCOORD2;
	float3 vHalfDirTS:		TEXCOORD3;
	float4 Ambient:			TEXCOORD4;
	float vFog:				FOG;
};

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	float3 vEyeDirOS=v4EyePosObject.xyz-IN.v4Position.xyz;
	float3 vLightDirOS=tosigned(IN.vLightDir.xyz);
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	OUT.Ambient=IN.v4Ambient*v4DiffuseColor;
	OUT.Diffuse.rgb=IN.vLightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=IN.vLightCol.a*v4Opacity.a*2;
#ifdef SPECULARENABLED
	OUT.Specular=IN.vLightCol*v4SpecularColor;
#else
	OUT.Specular=OUT.Diffuse;
#endif

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	float3 vEyeDirTS=normalize(IN.vEyeDirTS);
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	// Ambient
	OUT.col.rgb=IN.Ambient.rgb*cTexel.rgb;
	
	// Diffuse
	float3 vLightDirTS=IN.vLightDirTS;
	OUT.col.rgb+=saturate(dot(vLightDirTS,v3BumpNormal))*IN.Diffuse.rgb*cTexel.rgb;
	
	// Specular
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	//float3 vHalfDir=tosigned(tex2D(samplerCubeNormalizer,IN.vHalfDirTS));
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	OUT.col.rgb+=v3SpecularColor;
#endif

	// add the view/light dependent rim lighting
	float  fCosViewNormal=dot(v3BumpNormal,vEyeDirTS);
	float  fSinViewNormal=saturate(1.0-fCosViewNormal*fCosViewNormal);
	float  fBackLightStrength=pow(fSinViewNormal,fRimLightPower);
	OUT.col.rgb += saturate(dot(-vEyeDirTS,vLightDirTS))* fBackLightStrength*v4RimLightColor*fRimLightStrength;
	
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb*2,cTexel);
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// High quality lighting pass
//////////////////////////////////////////////////////////////////
struct v2fClothDiffuse {
    float4 Position     : POSITION;
	float4 Diffuse		: COLOR0;
	float4 Specular		: COLOR1;

	float4 vTexCoords	: TEXCOORD0;
    float3 LightVector  : TEXCOORD1;
    float3 HalfVector	: TEXCOORD2;
    float4 EyeVector	: TEXCOORD3;
    float4 LightVectorOS: TEXCOORD4;
	float4 TexShadow	: TEXCOORD5;
	float4 TexLightClip : TEXCOORD6;
	float vFog:			  FOG;
};

/****************************************************************
		DiffuseBumpSpecularRimLight_PS20
 ****************************************************************/
float4 DiffuseBumpSpecularRimLight_PS20(v2fClothDiffuse IN) : COLOR0 
{
	float4 OUT;

	// sampling stage
	float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
	float3 bumpnormal = CalculateBumpNormalPS(IN.vTexCoords); 
	
	float3 v2l = normalize(IN.LightVector);
	float3 v2e = IN.EyeVector;

	// add the diffuse and specular lighting contribution
	float  diffuse  = saturate(dot(bumpnormal, v2l));
	OUT.rgb = diffuse * color.xyz;
	
	// add the view/light dependent rim lighting
	float  fCosViewNormal=saturate(dot(bumpnormal,v2e));
	float  fSinViewNormal=1.0-fCosViewNormal*fCosViewNormal;
	float  fBackLightStrength=pow(fSinViewNormal,fRimLightPower);
	OUT.rgb += saturate(dot(-v2e,v2l))*fBackLightStrength*v4RimLightColor*fRimLightStrength;
	
	OUT.rgb *= IN.Diffuse;
	
#ifdef SPECULARENABLED
	float3 hv  = normalize(IN.HalfVector);
	float3 gloss = tex2D(samplerSpecularMask,IN.vTexCoords);
	float  specular = pow(saturate(dot(bumpnormal, hv)),v4SpecularPower.x)* vSpecularLevel;
	OUT.rgb += IN.Specular * v4SpecularColor.xyz * specular * gloss;
#endif
	
	// light and shadow factor
	OUT.rgb *= CalculateLightIntensity(IN.TexLightClip,IN.LightVectorOS);
	OUT.rgb *= GetShadowMapPS(IN.TexShadow,IN.EyeVector.w);

	OUT.a = CalculateAlpha(color.w*IN.Diffuse.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
/****************************************************************
		DiffuseBumpSpecularRimLight_VS20
 ****************************************************************/
v2fClothDiffuse DiffuseBumpSpecularRimLight_VS20(a2vStandardHQ IN) {
	v2fClothDiffuse OUT;

	CalcPosition(OUT.Position,IN.v4Position);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,IN.v4Position,tosigned(IN.v3Normal));
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	return OUT;
}

/****************************************************************
		DiffuseBumpSpecularRimLight_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularRimLight_VS20_PS20 < string Identifier="DiffuseBumpSpecularRimLight"; > {
	pass p0 {
		VertexShader=compile vs_2_0 DiffuseBumpSpecularRimLight_VS20();
		PixelShader=compile  ps_2_0 DiffuseBumpSpecularRimLight_PS20();

		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
/****************************************************************
		DiffuseBumpSpecularRimLightMPS_VS20
 ****************************************************************/
v2fClothDiffuse DiffuseBumpSpecularRimLightMPS_VS20(a2vStandardMPS IN)
{
	v2fClothDiffuse OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);

	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,v4PositionOut,v3NormalOut);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	return OUT;
}

/****************************************************************
		DiffuseBumpSpecularRimLightMPS_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularRimLightMPS_VS20_PS20 < string Identifier="DiffuseBumpSpecularRimLightMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0  DiffuseBumpSpecularRimLightMPS_VS20();
		PixelShader =compile ps_2_0 DiffuseBumpSpecularRimLight_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
