#include "StandardCommon.fx"

//
//	Fur shader for Shader Model 1.1 hardware
//

struct v2fFur
{
    float4 Position     : POSITION;
	float3 TexCoord0	: TEXCOORD0;
};

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

float4 PS_Base(v2fFur IN): COLOR
{
	//return float4(0.95, 0.65, 0.35, 1.0);	//gusten hudfarve
	float3 diffuse=tex2D(samplerDiffuse, IN.TexCoord0.xy);
	return float4(diffuse*0.5,1.0f);
}

#if defined(MESH_STANDARD) || defined(MESH_RIGID)

v2fFur VS_Base(a2vStandard IN) 
{
    v2fFur OUT;
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	OUT.TexCoord0.xyz = float3(IN.vTexCoords.xy,0);
    return OUT;
}

technique Ambient < string Identifier="Ambient"; 
//string Performance="Fastest";
> {
    pass Setup
    {		
		VertexShader = compile vs_1_1 VS_Base();
		PixelShader  = compile ps_1_1 PS_Base();

		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=false;	//fog f*** up!
//		FogColor=<vFogColor>;
    }
}
#endif	//defined(MESH_STANDARD) || defined(MESH_RIGID)

#if defined(MESH_WEIGHTED)
v2fFur VS_BaseMPS(a2vStandardMPS IN) 
{
    v2fFur OUT;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexCoord0.xyz = float3(IN.vTexCoords.xy,0);
    return OUT;
}


technique AmbientMPS < string Identifier="AmbientMPS"; //string Performance="Fastest"; 
> {
    pass Setup
    {		
		VertexShader = compile vs_1_1 VS_BaseMPS();
		PixelShader  = compile ps_1_1 PS_Base();
		
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
		
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=false;	//fog f*** up!
//		FogColor=<vFogColor>;
    }
}

#endif	//MESH_WEIGHTED
