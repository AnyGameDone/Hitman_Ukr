#include "StandardCommon.fx"


//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#if defined(MESH_STANDARD) || defined(MESH_TWEENED)

struct v2fStandardAmbientHQ20 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 Specular:		COLOR1;
	float4 vTexCoords:		TEXCOORD0;
	float3 vLightDirTS:		TEXCOORD1;
	float3 vEyeDirTS:		TEXCOORD2;
	float3 vHalfDirTS:		TEXCOORD3;
	float4 Ambient:			TEXCOORD4;
	float vFog:				FOG;
};

v2fStandardAmbientHQ20 AmbientHQ_VS20(a2vStandardHQ IN)
{
	v2fStandardAmbientHQ20 OUT;
	float3x3 m33TangentSpace;
	
#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float3 v3Tangent=lerp(tosigned(IN.v3Tangent),tosigned(IN.v3Tangent2),vTweenFactor);
	float3 v3Binormal=lerp(tosigned(IN.v3Binormal),tosigned(IN.v3Binormal2),vTweenFactor);
	float4 v4LightDir=lerp(tosigned(IN.vLightDir),tosigned(IN.vLightDir2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
	float4 v4LightCol=lerp(IN.vLightCol,IN.vLightCol2,vTweenFactor);
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float3 v3Tangent=tosigned(IN.v3Tangent);
	float3 v3Binormal=tosigned(IN.v3Binormal);
	float4 v4LightDir=tosigned(IN.vLightDir);
	float4 v4Diffuse=IN.vVertexCol;
	float4 v4LightCol=IN.vLightCol;
#endif

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalculateTangentSpace(m33TangentSpace,v3Tangent,v3Binormal,v3Normal);
	
	float3 vEyeDirOS=v4EyePosObject.xyz-v4Position.xyz;
	float3 vLightDirOS=v4LightDir.xyz;
	
	OUT.vLightDirTS=mul(m33TangentSpace,vLightDirOS);
	OUT.vEyeDirTS=normalize(mul(m33TangentSpace,vEyeDirOS));
	OUT.vHalfDirTS=normalize(OUT.vLightDirTS+OUT.vEyeDirTS);

	OUT.Ambient=IN.v4Ambient*v4DiffuseColor;
	OUT.Diffuse.rgb=v4LightCol.rgb*v4DiffuseColor.rgb;
	OUT.Diffuse.a=v4Diffuse.a*v4Opacity.a*CalculateAlphaFade(v4Position.xyz,v3Normal);
	
#ifdef SPECULARENABLED
	OUT.Specular=v4LightCol*v4SpecularColor;
#else
	OUT.Specular=OUT.Diffuse;
#endif

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif


	CalcPosition(OUT.Position,v4Position);
	
	//OUT.Position = mul(v4Position, m44ModelViewProj); // test !!
	
	
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	return OUT;
}

f2sStandard AmbientHQ_PS20(v2fStandardAmbientHQ20 IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	// Ambient
	OUT.col.rgb=IN.Ambient.rgb*cTexel.rgb;
	
	// Diffuse
	float3 vLightDirTS=IN.vLightDirTS;
	OUT.col.rgb+=saturate(dot(vLightDirTS,v3BumpNormal))*IN.Diffuse.rgb*cTexel.rgb;
	
	// Specular
#ifdef SPECULARENABLED
	float3 vHalfDir=normalize(IN.vHalfDirTS);
	//float3 vHalfDir=tosigned(tex2D(samplerCubeNormalizer,IN.vHalfDirTS));
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float vSpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,vHalfDir)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=vSpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	OUT.col.rgb+=v3SpecularColor;
#endif
	
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb*2,cTexel);
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
		
	//OUT.col = float4(1,0,0,0); // test
	
	return OUT;
}

technique AmbientHQ_VS20_PS20 < string Identifier="Ambient"; > {
	pass p0 {
		VertexShader=compile vs_1_1 AmbientHQ_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
// High quality ambient pass
//////////////////////////////////////////////////////////////////
#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
struct v2fStandardAmbientMPSHQ {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;
	float4 vTexCoords:		TEXCOORD0;
	float3 vLightDir1TS:	TEXCOORD1;
	float3 vLightDir2TS:	TEXCOORD2;
	float3 vLightDir3TS:	TEXCOORD3;
	float3 vHalfDir1TS:		TEXCOORD4;
	float3 vHalfDir2TS:		TEXCOORD5;
	float3 vHalfDir3TS:		TEXCOORD6;
	float3 vEyeDirTS:		TEXCOORD7;
	float vFog:				FOG;
};

f2sStandard AmbientHQ_MPS_PS20(v2fStandardAmbientMPSHQ IN) 
{
	f2sStandard OUT;
	float2 vTexCoords;//=IN.vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTS);
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords);
	
	float3 vLightDir1TS=IN.vLightDir1TS;
	float3 vLightDir2TS=IN.vLightDir2TS;
	float3 vLightDir3TS=IN.vLightDir3TS;
	OUT.col.rgb =v4BonesLights[1].rgb*saturate(dot(vLightDir1TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[3].rgb*saturate(dot(vLightDir2TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[5].rgb*saturate(dot(vLightDir3TS,v3BumpNormal));
	OUT.col.rgb+=v4BonesLights[6].rgb;
	OUT.col.rgb*=IN.Diffuse.rgb*cTexel.rgb*v4DiffuseColor*2;
	
#ifdef SPECULARENABLED
	float3 vHalfDir1=normalize(IN.vHalfDir1TS);
	float3 vHalfDir2=normalize(IN.vHalfDir2TS);
	float3 vHalfDir3=normalize(IN.vHalfDir3TS);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float3 vSpecular1=v4BonesLights[1].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir1)),v4SpecularPower.x);
	float3 vSpecular2=v4BonesLights[3].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir2)),v4SpecularPower.x);
	float3 vSpecular3=v4BonesLights[5].rgb*pow(saturate(dot(v3BumpNormal.xyz,vHalfDir3)),v4SpecularPower.x);
	float3 vSpecular=vSpecular1+vSpecular2+vSpecular3;
	float3 v3SpecularColor=vSpecular*v3SpecularMask*vSpecularLevel*v4SpecularColor*2;
	OUT.col.rgb+=v3SpecularColor;
#endif
		
	OUT.col.rgb=CalculateDebugColorPS(OUT.col.rgb,cTexel);
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	
	return OUT;
}
#endif

#if defined(MESH_RIGID)
v2fStandardAmbientMPSHQ AmbientHQ_Rigid_VS20(a2vStandardRigid IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.vEyeDirTS=mul(m33TangentSpace,v4EyePosObject-IN.v4Position);
	OUT.Diffuse.rgb=IN.vVertexCol.rgb;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	
	return OUT;
}

technique AmbientHQ_Rigid_VS20_PS20 < string Identifier="AmbientRigid"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_Rigid_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardAmbientMPSHQ AmbientHQ_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardAmbientMPSHQ OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,v4PositionOut);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	// Calculate lighting
	CalcBonesLightHQ(OUT.vLightDir1TS,OUT.vLightDir2TS,OUT.vLightDir3TS,OUT.vHalfDir1TS,OUT.vHalfDir2TS,OUT.vHalfDir3TS,m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.vEyeDirTS=mul(m33TangentSpace,v4EyePosObject-v4PositionOut);
	OUT.Diffuse.rgb=IN.v4Diffuse.rgb;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;

	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
//#ifdef PARALLAXENABLED
	OUT.vTexCoords.zw=0;
	//CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
//#endif

	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	
	return OUT;
}

technique AmbientHQ_MPS_VS20_PS20 < string Identifier="AmbientMPS"; > {
	pass p0 {
		VertexShader=compile vs_2_0 AmbientHQ_MPS_VS20();
		PixelShader=compile ps_2_0 AmbientHQ_MPS_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=<vFogColor>;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardShadowMap {
	float4 Position:			POSITION;
	float4 vShadowCoords:		TEXCOORD0;
	float2 vTexCoords:		TEXCOORD1;
};

f2sStandard ShadowMap_PS20(v2fStandardShadowMap IN) {
	f2sStandard OUT;
	float2 vTexCoords=IN.vTexCoords;
#ifdef BLENDENABLED
	float fAlphaValue=tex2D(samplerDiffuse,vTexCoords).a;
	clip(fAlphaValue-0.5);
#endif
	CalculateShadowMapPS(OUT.col,IN.vShadowCoords.x);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

v2fStandardShadowMap ShadowMap_VS20(a2vStandardHQ IN) {
	v2fStandardShadowMap OUT;
	
	OUT.Position=mul(m44WorldShadowProj,IN.v4Position);
	OUT.vTexCoords.xy=IN.vTexCoords;
	CalculateShadowMapVS(OUT.vShadowCoords,IN.v4Position);
	CalcTextureCoords(OUT.vTexCoords.xy,OUT.vTexCoords.xy);
	
	return OUT;
}

technique ShadowMap_VS20_PS20 < string Identifier="ShadowMap";> {
	pass p0 {
		VertexShader=compile vs_1_1 ShadowMap_VS20();
		PixelShader=compile ps_2_0 ShadowMap_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

#if defined(MESH_RIGID)

v2fStandardShadowMap ShadowMapRigid_VS20(a2vStandardRigid IN) {
	v2fStandardShadowMap OUT;
	
	OUT.Position=mul(m44WorldShadowProj,IN.v4Position);
	OUT.vTexCoords.xy=IN.vTexCoords;
	CalculateShadowMapVS(OUT.vShadowCoords,IN.v4Position);
	CalcTextureCoords(OUT.vTexCoords.xy,OUT.vTexCoords.xy);
	
	return OUT;
}

technique ShadowMapRigid_VS20_PS20 < string Identifier="ShadowMapRigid";> {
	pass p0 {
		VertexShader=compile vs_1_1 ShadowMapRigid_VS20();
		PixelShader=compile ps_2_0 ShadowMap_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

#if defined(MESH_WEIGHTED)

v2fStandardShadowMap ShadowMapMPS_VS20(a2vStandardMPS IN) {
	v2fStandardShadowMap OUT;
	
	OUT.vTexCoords=IN.vTexCoords;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	OUT.Position=mul(m44WorldShadowProj,v4PositionOut);
	CalculateShadowMapVS(OUT.vShadowCoords,v4PositionOut);
	
	return OUT;
}

technique ShadowMapMPS_VS20_PS20 < string Identifier="ShadowMapMPS";> {
	
	pass p0 {
		VertexShader=compile vs_1_1 ShadowMapMPS_VS20();
		PixelShader=compile ps_2_0 ShadowMap_PS20();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
/*struct v2fStandardSoftShadowMake {
	float4 Position:			POSITION;
	float4 vShadowCoords:			TEXCOORD0;
	float4 PosLightSpace:		TEXCOORD1;
	float4 vShadowCoords2:			TEXCOORD2;
	float4 PosLightSpace2:		TEXCOORD3;
};

f2sStandard SoftShadowBufferMake_PS20(v2fStandardSoftShadowMake IN) {
	f2sStandard OUT;

	OUT.col=1;

	float fLightDist1=IN.PosLightSpace;
	float fShadowDepth1=tex2Dproj(samplerShadowColor,IN.vShadowCoords).r;
	//OUT.col.r=fShadowDepth1>=fLightDist1?1:0;
	OUT.col.r=fShadowDepth1;
	
	float fLightDist2=IN.PosLightSpace2;
	float fShadowDepth2=tex2Dproj(samplerShadowColor2,IN.vShadowCoords2).r;
	//OUT.col.g=fShadowDepth2>=fLightDist2?1:0;
	OUT.col.g=fShadowDepth2;
	

	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

v2fStandardSoftShadowMake SoftShadowBufferMake_VS20(a2vStandardHQ IN) {
	v2fStandardSoftShadowMake OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	
	CalculateShadowMapVS(OUT.vShadowCoords,OUT.PosLightSpace,IN.v4Position);
	CalculateShadow2VS(OUT.vShadowCoords2,OUT.PosLightSpace2,IN.v4Position);
	
	return OUT;
}

technique SoftShadowMake_VS20_PS20 < string Identifier="SoftShadowMap";> {
	
	pass p0 {
		VertexShader=compile vs_1_1 SoftShadowBufferMake_VS20();
		PixelShader=compile ps_2_0 SoftShadowBufferMake_PS20();
		
		AlphaBlendEnable=<BlendEnabled>;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

#if defined(MESH_WEIGHTED)

v2fStandardSoftShadowMake ShadowMapMPS_VS20(a2vStandardMPS IN) {
	v2fStandardSoftShadowMake OUT;
	
	OUT.vTexCoords=IN.vTexCoords;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	OUT.Position=mul(m44WorldLightProj,v4PositionOut);
	OUT.TexDepth=CalculateShadowDepth(v4PositionOut);
	
	return OUT;
}

technique ShadowMapMPS_VS20_PS20 < string Identifier="ShadowMapMPS";> {
	
	pass p0 {
		VertexShader=compile vs_1_1 ShadowMapMPS_VS20();
		PixelShader=compile ps_2_0 ShadowMap_PS20();
		
		AlphaBlendEnable=<BlendEnabled>;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif*/

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardShadowDrop20 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 TexLightDir2:		TEXCOORD0;
	float4 vShadowCoords:		TEXCOORD1;
	float4 TexLightClip:		TEXCOORD2;
	float4 vShadowClip:			TEXCOORD3;
	float vFog:					FOG;
};

f2sStandard ShadowDrop_PS20(v2fStandardShadowDrop20 IN) {

	f2sStandard OUT;

	float vLightAttenuation=saturate(IN.TexLightClip).w; // Backfacing attenuation for spots)
	//float vLightAttenuation=CalculateLightIntensity(IN.TexLightClip,IN.TexLightDir2).r;
	float vShadowAttenuation=GetDropShadowMapPS(IN.vShadowCoords,IN.vShadowClip);
	OUT.col=vShadowAttenuation*vLightAttenuation*IN.Diffuse;
	
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardShadowDrop20 ShadowDrop_VS20(a2vStandardHQ IN) {
	v2fStandardShadowDrop20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-IN.v4Position.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul(m44WorldLightClipProj,IN.v4Position);
	OUT.TexLightClip=vPositionLSOut;
	OUT.TexLightDir2=vLightDirScaledOSOut;
	
	OUT.Diffuse=1-g_vDropShadowColor;
	OUT.Diffuse*=g_vDropShadowColor.a;
	// Calculate angular fade
	float3 vLightDirOS=normalize(v4LightPosObject.xyz-IN.v4Position.xyz);
	//float fDot=max(dot(tosigned(IN.v3Normal),vLightDirOS),0);
	float fDot=clamp(dot(tosigned(IN.v3Normal),vLightDirOS)*8,0,1);
	OUT.Diffuse*=fDot;
	// Calculate distance fade
	float fDistFade=saturate(vLightDirScaledOSOut.w-dot(vLightDirScaledOSOut.xyz,vLightDirScaledOSOut.xyz));
	OUT.Diffuse*=fDistFade;
	
		
	GetDropShadowMapVS(OUT.vShadowCoords,OUT.vShadowClip,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique ShadowDrop_VS20_PS20 < string Identifier="ShadowDrop"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 ShadowDrop_VS20();
		PixelShader=compile ps_2_0 ShadowDrop_PS20();
		
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if  defined(MESH_RIGID)
v2fStandardShadowDrop20 ShadowDropRigid_VS20(a2vStandardRigid IN) {
	v2fStandardShadowDrop20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-IN.v4Position.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul(m44WorldLightClipProj,IN.v4Position);
	OUT.TexLightClip=vPositionLSOut;
	OUT.TexLightDir2=vLightDirScaledOSOut;
	
	OUT.Diffuse=1-g_vDropShadowColor;
	OUT.Diffuse*=g_vDropShadowColor.a;
	// Calculate angular fade
	float3 vLightDirOS=normalize(v4LightPosObject.xyz-IN.v4Position.xyz);
	float fDot=max(dot(tosigned(IN.v3Normal),vLightDirOS),0);
	OUT.Diffuse*=fDot;
		
	GetDropShadowMapVS(OUT.vShadowCoords,OUT.vShadowClip,IN.v4Position);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique ShadowDropRigid_VS20_PS20 < string Identifier="ShadowDropRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 ShadowDropRigid_VS20();
		PixelShader=compile ps_2_0 ShadowDrop_PS20();
		
		AlphaBlendEnable=true;
		AlphaTestEnable=false;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
struct v2fStandardShadowDropMPS20 {
	float4 Position:			POSITION;
	float4 vLightDirOS:			TEXCOORD0;
	float4 vShadowCoords:		TEXCOORD1;
	float4 vLightClipCoords:	TEXCOORD2;
	float3 vNormalOS:			TEXCOORD3;
	float vFog:					FOG;
};

f2sStandard ShadowDrop_MPS_PS20(v2fStandardShadowDropMPS20 IN) {

	f2sStandard OUT;

	float3 vLightAttenuation=CalculateLightIntensity(IN.vLightClipCoords,IN.vLightDirOS);
	
	float fLightDepth=IN.vShadowCoords.z/IN.vShadowCoords.w;
	fLightDepth=fLightDepth*0.999-0.005;
	float fShadowDepth=tex2Dproj(samplerShadowColor,IN.vShadowCoords).r;
	float vShadowAttenuation=fShadowDepth>=fLightDepth?0:1;
	
	float fBackFacing=saturate(dot(IN.vLightDirOS,IN.vNormalOS));
	//vShadowAttenuation*=fBackFacing;
		
	OUT.col.rgb=vShadowAttenuation*vLightAttenuation*0.5;
	OUT.col.a=1;
	return OUT;
}

v2fStandardShadowDropMPS20 ShadowDrop_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardShadowDropMPS20 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	
	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.vNormalOS=v3NormalOut;
	
	// Output scaled light direction for attenuation
	float4 vLightDirScaledOSOut;
	float3 vLightDirObject=v4LightPosObject.xyz-v4PositionOut.xyz;
	vLightDirScaledOSOut.xyz=vLightDirObject*v4LightAttributes.y;
	vLightDirScaledOSOut.w=v4LightAttributes.x;
	// Output position in light space to create back clipping
	float4 vPositionLSOut=mul(m44WorldLightClipProj,v4PositionOut);
	OUT.vLightClipCoords=vPositionLSOut;
	OUT.vLightDirOS=vLightDirScaledOSOut;
	
	float fShadowDepth;
	GetShadowMapVS(OUT.vShadowCoords,fShadowDepth,v4PositionOut,v3NormalOut);
	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	return OUT;
}

technique ShadowDrop_MPS_VS20_PS2 < string Identifier="ShadowDropMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 ShadowDrop_MPS_VS20();
		PixelShader=compile ps_2_0 ShadowDrop_MPS_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=Zero;
		DestBlend=InvSrcColor;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
struct v2fStandardLighting20 {
	float4 Position:			POSITION;
	float4 Diffuse:				COLOR0;
	float4 Specular:			COLOR1;
	float4 vTexCoords:			TEXCOORD0;
	float3 TexLightDir:			TEXCOORD1;
	float4 TexLightDir2:		TEXCOORD2;
	float3 TexHalfAngleDir:		TEXCOORD3;
	float4 TexEyeDir:			TEXCOORD4;
	float4 vShadowCoords:		TEXCOORD5;
	float4 TexLightClip:		TEXCOORD6;
	float vFog:					FOG;
};

f2sStandard Lighting_PS20(v2fStandardLighting20 IN) {

	f2sStandard OUT;

	// Read base stuff
	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.TexEyeDir);
	float4 cTexel=tex2D(samplerDiffuse,vTexCoords); 
	float3 v3BumpNormal=CalculateBumpNormalPS(vTexCoords);
	
	float3 vLightAttenuation=CalculateLightIntensity(IN.TexLightClip,IN.TexLightDir2);
	float vShadowAttenuation=GetShadowMapPS(IN.vShadowCoords,IN.TexEyeDir.w);
	
	float3 vResultColor;

	// Diffuse
	float3 v3LightDir=normalize(IN.TexLightDir.xyz);
	float v1DiffuseIntensity=saturate(dot(v3BumpNormal.xyz,v3LightDir));
	float3 v3DiffuseColor=v1DiffuseIntensity*IN.Diffuse.rgb*cTexel.rgb;
	vResultColor=v3DiffuseColor;
	
#ifdef SPECULARENABLED
	float3 v3HalfAngleVector=normalize(IN.TexHalfAngleDir);
	float3 v3SpecularMask=tex2D(samplerSpecularMask,vTexCoords).rgb;
	float v1SpecularIntensity=pow(saturate(dot(v3BumpNormal.xyz,v3HalfAngleVector)),v4SpecularPower.x)*vSpecularLevel;
	float3 v3SpecularColor=v1SpecularIntensity*IN.Specular.rgb*v3SpecularMask;
	vResultColor+=v3SpecularColor;
#endif

	OUT.col.rgb=vResultColor*vShadowAttenuation*vLightAttenuation;
	OUT.col.a=CalculateAlpha(IN.Diffuse.a*cTexel.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardLighting20 Lighting_VS20(a2vStandardHQ IN) {
	v2fStandardLighting20 OUT;

#ifdef MESH_TWEENED
	float4 v4Position=lerp(IN.v4Position,IN.v4Position2,vTweenFactor);
	float3 v3Normal=lerp(tosigned(IN.v3Normal),tosigned(IN.v3Normal2),vTweenFactor);
	float3 v3Tangent=lerp(tosigned(IN.v3Tangent),tosigned(IN.v3Tangent2),vTweenFactor);
	float3 v3Binormal=lerp(tosigned(IN.v3Binormal),tosigned(IN.v3Binormal2),vTweenFactor);
	float4 v4LightDir=lerp(tosigned(IN.vLightDir),tosigned(IN.vLightDir2),vTweenFactor);
	float4 v4Diffuse=lerp(IN.vVertexCol,IN.vVertexCol2,vTweenFactor);
#else
	float4 v4Position=IN.v4Position;
	float3 v3Normal=tosigned(IN.v3Normal);
	float3 v3Tangent=tosigned(IN.v3Tangent);
	float3 v3Binormal=tosigned(IN.v3Binormal);
	float4 v4LightDir=tosigned(IN.vLightDir);
	float4 v4Diffuse=IN.vVertexCol;
#endif

	CalcPosition(OUT.Position,v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3Tangent,v3Binormal,v3Normal);
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,v4Diffuse);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,v4Position,v3Normal);
	CalculateFog(OUT.vFog,v4Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique Lighting_VS20_PS20 < string Identifier="Lighting"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Lighting_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardLighting20 LightingRigid_VS20(a2vStandardRigid IN) {
	v2fStandardLighting20 OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.vVertexCol);
	OUT.Diffuse.a*=CalculateAlphaFade(IN.v4Position,tosigned(IN.v3Normal));
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,IN.v4Position,IN.v3Normal);
	CalculateFog(OUT.vFog,IN.v4Position.xyz);
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	return OUT;
}

technique LightingRigid_VS20_PS20 < string Identifier="LightingRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 LightingRigid_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif


#if defined(MESH_WEIGHTED)
v2fStandardLighting20 Lighting_MPS_VS20(a2vStandardMPS IN)
{
	v2fStandardLighting20 OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS(OUT.TexLightDir,OUT.TexHalfAngleDir,OUT.TexEyeDir.xyz,OUT.TexLightDir2,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	CalculateColorVS(OUT.Diffuse,OUT.Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.vShadowCoords,OUT.TexEyeDir.w,v4PositionOut,v3NormalOut);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	return OUT;
}

technique Lighting_MPS_VS20_PS2 < string Identifier="LightingMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Lighting_MPS_VS20();
		PixelShader=compile ps_2_0 Lighting_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
#ifdef ILLUMINATIONENABLED
struct v2fStandardIlluminate {
	float4 Position:			POSITION;
	float4 IlluminateColor:		COLOR0;
	float2 TexDiffuse1:			TEXCOORD0;
	float2 TexDiffuse2:			TEXCOORD1;
	float vFog:					FOG;
};

f2sStandard Illuminate_PS20(v2fStandardIlluminate IN) {

	f2sStandard OUT;
	float4 cBase=tex2D(samplerDiffuse,IN.TexDiffuse1);
	float4 cIllum=tex2D(samplerIllumination,IN.TexDiffuse2);
	OUT.col.rgb=cBase.rgb*cIllum.rgb*IN.IlluminateColor.rgb;
	OUT.col.a=CalculateAlpha(cBase.a*cIllum.a*IN.IlluminateColor.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardIlluminate Illuminate_VS20(a2vStandardHQ IN) {

	v2fStandardIlluminate OUT;

	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalcPosition(OUT.Position,IN.v4Position);					
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;
	
	
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique Illuminate_VS20_PS20 < string Identifier="Illuminate"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Illuminate_VS20();
		PixelShader=compile ps_2_0 Illuminate_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardIlluminate IlluminateRigid_VS20(a2vStandardRigid IN) {

	v2fStandardIlluminate OUT;

	//OUT.Position=mul(IN.v4Position, m44ModelViewProj);
	CalcPosition(OUT.Position,IN.v4Position);					
	CalcTextureCoords(OUT.TexDiffuse1.xy,IN.vTexCoords);
	CalcTextureCoords(OUT.TexDiffuse2.xy,IN.vTexCoords);
	OUT.IlluminateColor.rgb=IN.vVertexCol.rgb*v4IlluminationColor.rgb;
	OUT.IlluminateColor.a=IN.vVertexCol.a*v4Opacity.a;
	
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique IlluminateRigid_VS20_PS20 < string Identifier="IlluminateRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 IlluminateRigid_VS20();
		PixelShader=compile ps_2_0 Illuminate_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#endif


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#ifdef REFLECTIONENABLED
struct v2fStandardReflection {
	float4 Position:			POSITION;
	float4 Reflection:			COLOR0;
	float4 vTexCoords:			TEXCOORD0;
	float3 TangentToCubeSpace0: TEXCOORD1;
	float3 TangentToCubeSpace1: TEXCOORD2;
	float3 TangentToCubeSpace2: TEXCOORD3;
	float3 vEyeDirCubeSpace:	TEXCOORD4;
	float3 vEyeDirTangentSpace: TEXCOORD5;
	float vFog:					FOG;
};

f2sStandard Reflection_PS20(v2fStandardReflection IN) {
	
	f2sStandard OUT;

	float2 vTexCoords;
	CalculateTexCoordsPS(vTexCoords,IN.vTexCoords,IN.vEyeDirTangentSpace);
	
	float4 mask=tex2D(samplerReflectionMask,vTexCoords);
	float3 vNormalTangentSpace=CalculateBumpNormalPS(vTexCoords);
	float3 cFallOff=tex2D(samplerReflectionFallOff,1-saturate(IN.vEyeDirTangentSpace.z));

	// fetch the bump normal from the normal map
	float3 vNormalCubeSpace;
	vNormalCubeSpace.x=dot(IN.TangentToCubeSpace0,vNormalTangentSpace);
	vNormalCubeSpace.y=dot(IN.TangentToCubeSpace1,vNormalTangentSpace);
	vNormalCubeSpace.z=dot(IN.TangentToCubeSpace2,vNormalTangentSpace);
	// = (IN.TangentTypeCubeSpace0.z,IN.TangentTypeCubeSpace1.z,IN.TangentTypeCubeSpace2.z)
	float3 vReflected=reflect(-IN.vEyeDirCubeSpace,vNormalCubeSpace);
	
	float3 cReflect=texCUBE(samplerEnvironment,vReflected).rgb;
	cReflect=CalculateDebugColorPS(cReflect*IN.Reflection.rgb,cReflect);
	
	OUT.col.rgb=mask.rgb*cReflect*cFallOff*vReflectionLevel;
	OUT.col.a=1;
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardReflection Reflection_VS20(a2vStandardHQ IN) {

	v2fStandardReflection OUT;
	
	float4 v4Position = IN.v4Position;
	float3 v3Normal = tosigned(IN.v3Normal);

#ifdef WOBBLEENABLED
	float fWobble = cos(fWobbleWaveLength * (vEngineTime - (IN.vTexCoords.x * fWobbleUSpeed) - (IN.vTexCoords.y * fWobbleVSpeed)));
	v4Position.xyz += fWobblePosAmplitude * v3Normal * fWobble;
	v3Normal.x += fWobbleNorAmplitude * fWobble;
#endif

	CalcPosition(OUT.Position,v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),v3Normal);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-v4Position.xyz;
	OUT.vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=v4ReflectionColor*(max(dot(v3Normal,tosigned(IN.vLightDir)),0)*IN.vLightCol+IN.v4Ambient);
	
	CalculateFog(OUT.vFog,v4Position.xyz);

	return OUT;
}

technique Reflection_VS20_PS20 < string Identifier="Reflection"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 Reflection_VS20();
		PixelShader=compile ps_2_0 Reflection_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardReflection ReflectionRigid_VS20(a2vStandardRigid IN) {

	v2fStandardReflection OUT;

	CalcPosition(OUT.Position,IN.v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-IN.v4Position.xyz;
	OUT.vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=v4ReflectionColor;//*(max(dot(IN.v3Normal,IN.vLightDir),0)*IN.vLightCol+IN.v4Ambient);
	OUT.Reflection*=v4BonesLights[6].a;
	
	CalculateFog(OUT.vFog,IN.v4Position.xyz);

	return OUT;
}

technique ReflectionRigid_VS20_PS20 < string Identifier="ReflectionRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_2_0 ReflectionRigid_VS20();
		PixelShader=compile ps_2_0 Reflection_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
v2fStandardReflection ReflectionMPS_VS20(a2vStandardMPS IN) {

	v2fStandardReflection OUT;

	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);
	
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	
	//CalcPosition(OUT.Position,IN.v4Position);

	// Create object to tangent space matrix
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);

	// Create matrix to transform from tangent space to cube space
	float3x3 m33ObjToCubeSpace;
	m33ObjToCubeSpace[0]=m34ObjToCubeSpace[0].xyz;
	m33ObjToCubeSpace[1]=m34ObjToCubeSpace[1].xyz;
	m33ObjToCubeSpace[2]=m34ObjToCubeSpace[2].xyz;
	OUT.TangentToCubeSpace0.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[0].xyz);
	OUT.TangentToCubeSpace1.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[1].xyz);
	OUT.TangentToCubeSpace2.xyz=mul(m33TangentSpace,m34ObjToCubeSpace[2].xyz);
	
	// Calculate eye position in cube space
	float3 vEyeDir=v4EyePosObject.xyz-v4PositionOut.xyz;
	OUT.vEyeDirCubeSpace=mul(m33ObjToCubeSpace,vEyeDir);
	
	OUT.vEyeDirTangentSpace=normalize(mul(m33TangentSpace,vEyeDir));

	// And move colors over
	OUT.Reflection=v4ReflectionColor;//*(max(dot(IN.v3Normal,IN.vLightDir),0)*IN.vLightCol+IN.v4Ambient);
	OUT.Reflection*=v4BonesLights[6].a;
	
	CalculateFog(OUT.vFog,v4PositionOut.xyz);

	return OUT;
}

technique ReflectionMPS_VS20_PS20 < string Identifier="ReflectionMPS"; > 
{	
	pass p0 
	{
		VertexShader=compile vs_2_0 ReflectionMPS_VS20();
		PixelShader=compile ps_2_0 Reflection_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#endif

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
struct v2fStandardZPass {
	float4 Position:	POSITION;
	float4 Diffuse:		COLOR0;
	float2 TexDiffuse:	TEXCOORD0;
};

f2sStandard ZPass_PS11(v2fStandardZPass IN) 
{
	f2sStandard OUT;
	
	OUT.col=IN.Diffuse;
#ifdef BLENDENABLED
	float4 cTexel=tex2D(samplerDiffuse,IN.TexDiffuse.xy);
	OUT.col.a=CalculateAlpha(2*IN.Diffuse.a*cTexel.a);
#endif
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED)
v2fStandardZPass ZPass_VS11(a2vStandardHQ IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	float f;
	CalculateFog(f,IN.v4Position.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPass"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPass_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}

v2fStandardZPass ZPassAlpha_VS11(a2vStandardHQ IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	OUT.Diffuse.rgb=lerp(float3(0,0,0),vFogColor.rgb,1-IN.vVertexCol.a);
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPass_VS11_PS11 < string Identifier="PostFilterZPassAlpha"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassAlpha_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif

#if defined(MESH_RIGID)
v2fStandardZPass ZPassRigid_VS11(a2vStandardRigid IN)
{
	v2fStandardZPass OUT;
	
	CalcPosition(OUT.Position,IN.v4Position);
	CalcTextureCoords(OUT.TexDiffuse.xy,IN.vTexCoords);
	float f;
	CalculateFog(f,IN.v4Position.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.vVertexCol.a*v4Opacity.a;

	return OUT;
}

technique ZPassRigid_VS11_PS11 < string Identifier="PostFilterZPassRigid"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassRigid_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif


#ifdef MESH_WEIGHTED

v2fStandardZPass ZPassMPS_VS11(a2vStandardMPS IN)
{
	v2fStandardZPass OUT;
	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);

	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	OUT.TexDiffuse=IN.vTexCoords;
	float f; 
	CalculateFog(f,v4PositionOut.xyz);
	OUT.Diffuse.rgb=1-f.rrr;
	OUT.Diffuse.a=IN.v4Diffuse.a*v4Opacity.a;
	
	return OUT;
}

technique ZPassMPS_VS11_PS11 < string Identifier="PostFilterZPassMPS"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ZPassMPS_VS11();
		PixelShader=compile ps_1_1 ZPass_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=true;
		FogEnable=false;
	}
}
#endif





float4x4 m44TextureProjectionMatrix;
float4 v4TextureProjectionColor;
float4 v4TextureProjectionLightPos;

texture mapTextureProjection2D;
sampler samplerTextureProjection2D = sampler_state
{
	texture =<mapTextureProjection2D>;
	minFilter=LINEAR;
	magFilter=LINEAR;
	mipFilter=POINT;
	// AddressU/V not set on purpose
	AddressW=CLAMP;
};

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)

struct v2fTextureProjection20 
{
	float4 Position:		POSITION;
	float4 Color:			COLOR0;
	float4 vTex0:			TEXCOORD0;
	float vFog:			FOG;
};

f2sStandard TextureProjection_PS20(v2fTextureProjection20 IN)
{
	f2sStandard OUT;
	float4 col = tex2Dproj( samplerTextureProjection2D, IN.vTex0);
	OUT.col = IN.Color*col;		
	return OUT;
}

v2fTextureProjection20 TextureProjection_VS20(a2vStandard IN)
{	
	v2fTextureProjection20 OUT;		
	float4 v4PositionOut = mul(m44World,IN.v4Position);
	OUT.vTex0 = mul(v4PositionOut, m44TextureProjectionMatrix);					
	CalcPosition(OUT.Position,IN.v4Position);		
	float3 vLightDirOS = normalize(v4TextureProjectionLightPos.xyz-IN.v4Position);  // object space light pos  - object space vertex position
	float fDot = saturate( dot( vLightDirOS.xyz, tosigned(IN.v3Normal) ) );  		
	OUT.Color = (1-v4TextureProjectionColor) * (0.3f+0.45f*fDot);
	CalculateFog(OUT.vFog,v4PositionOut);		
	return OUT;
}

technique TextureProjection_VS20_PS2 < string Identifier="TextureProjection"; > 
{	
	pass p0 {
		VertexShader=compile vs_2_0 TextureProjection_VS20();
		PixelShader=compile ps_2_0 TextureProjection_PS20();		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

technique TextureProjectionAdditive_VS20_PS2 < string Identifier="TextureProjectionAdditive"; > 
{	
	pass p0 {
		VertexShader=compile vs_2_0 TextureProjection_VS20();
		PixelShader=compile ps_2_0 TextureProjection_PS20();		
		AlphaBlendEnable=true;
		SrcBlend=DESTCOLOR;
		DestBlend=ONE;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

#endif



#if defined(MESH_WEIGHTED)

struct v2fTextureProjectionMPS20 
{
	float4 Position:		POSITION;	
	float4 Color:			COLOR0;	
	float4 vTex0:			TEXCOORD0;	
	float vFog:			FOG;
};

f2sStandard TextureProjection_MPS_PS20(v2fTextureProjectionMPS20 IN)
{
	f2sStandard OUT;
	float4 col = tex2Dproj( samplerTextureProjection2D, IN.vTex0);			
	OUT.col = IN.Color*col;	
	return OUT;
}

v2fTextureProjectionMPS20 TextureProjection_MPS_VS20(a2vStandardMPS IN)
{
	v2fTextureProjectionMPS20 OUT;	
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);	
	float4 v4PositionOut2 = mul(m44World,v4PositionOut);
	OUT.vTex0 = mul(v4PositionOut2, m44TextureProjectionMatrix);			
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3 vLightDirOS = normalize(v4TextureProjectionLightPos.xyz-v4PositionOut.xyz);  // object space light pos  - object space vertex position		
	float fDot = saturate( 2*dot( vLightDirOS.xyz, v3NormalOut ) );
	OUT.Color = (1-v4TextureProjectionColor) * (0.3f+0.45f*fDot);			
	CalculateFog(OUT.vFog,v4PositionOut.xyz);
	return OUT;
}

technique TextureProjection_MPS_VS20_PS2 < string Identifier="TextureProjectionMPS"; > 
{	
	pass p0 {
		VertexShader=compile vs_2_0 TextureProjection_MPS_VS20();
		PixelShader=compile ps_2_0 TextureProjection_MPS_PS20();		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

technique TextureProjectionAdditive_MPS_VS20_PS2 < string Identifier="TextureProjectionAdditiveMPS"; > 
{	
	pass p0 {
		VertexShader=compile vs_2_0 TextureProjection_MPS_VS20();
		PixelShader=compile ps_2_0 TextureProjection_MPS_PS20();		
		AlphaBlendEnable=true;
		SrcBlend=DESTCOLOR;
		DestBlend=ONE;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

#endif
