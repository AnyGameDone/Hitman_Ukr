#include "standardcommon.fx"

struct f2sSkin {
	float4 col:		COLOR0;
};

/****************************************************************
		DiffuseBumpSpecularTransRimLight_PS20
 ****************************************************************/

// Vertex to Fragment stuff
struct v2fSkinDiffuse {
    float4 Position     : POSITION;
	float4 Diffuse		: COLOR0;
	//float4 Specular		: COLOR1;
	float4 vTexCoords	: TEXCOORD0;
    float3 LightVector  : TEXCOORD1;
    float3 HalfVector	: TEXCOORD2;
    float4 EyeVector	: TEXCOORD3;
    float4 LightVectorOS: TEXCOORD4;
	float4 TexShadow	: TEXCOORD5;
	float4 TexLightClip : TEXCOORD6;
	float3 EyeVectorOS	: TEXCOORD7;
};

float4 DiffuseBumpSpecularTransRimLight_PS20(v2fSkinDiffuse IN) : COLOR0 
{
	float4 OUT;

	// sampling stage
	float4 color =  tex2D(samplerDiffuse,IN.vTexCoords);
	float3 bumpnormal = CalculateBumpNormalPS(IN.vTexCoords); 
	
	
	float3 v2l = normalize(IN.LightVector);
	float3 v2e = IN.EyeVector;
	float3 hv  = normalize(IN.HalfVector);
	float3 v2lOS = normalize(IN.LightVectorOS);
	float3 v2eOS = IN.EyeVectorOS;
	float3 transweights = tex2D(samplerTranslucency,IN.vTexCoords);

	// add the diffuse and specular lighting contribution
	float diffuse  = saturate(dot(bumpnormal, v2l));
	OUT.rgb = diffuse * color;

	// add the view/light dependent rim lighting
	float  fCosViewNormal=saturate(dot(bumpnormal,v2e));
	float  fSinViewNormal=1.0-fCosViewNormal*fCosViewNormal;
	float  fBackLightStrength=pow(fSinViewNormal,fRimLightPower);
	OUT.rgb += saturate(dot(-v2e,v2l))*fBackLightStrength*v4RimLightColor*fRimLightStrength;
	
	// add the translucency contribution
	OUT.rgb += v4SubSurfaceColor * fSubSurfaceTransparency*abs(dot(transweights,v2eOS))*saturate(dot(-v2e, v2l));

	// And apply lighting	
	OUT.rgb *= IN.Diffuse.rgb;
	
#ifdef SPECULARENABLED
	float3 gloss = tex2D(samplerSpecularMask,IN.vTexCoords);
	float  specular = pow(saturate(dot(bumpnormal, hv)),v4SpecularPower.x) * vSpecularLevel;
#if defined(MESH_WEIGHTED) || defined(MESH_RIGID)
	specular*=g_vBoneShadowMultiplier;
#endif
	//OUT.rgb += IN.Specular.rgb * specular*gloss;
	OUT.rgb += v4SpecularColor*v4LightColor*specular*gloss;
#endif
	
	// light and shadow factor
	OUT.rgb *= CalculateLightIntensity(IN.TexLightClip,IN.LightVectorOS);
	OUT.rgb *= GetShadowMapPS3(IN.TexShadow,IN.EyeVector.w);
	
	// final gathering and exit point
	OUT.a = CalculateAlpha(color.w * IN.Diffuse.a);
	return OUT;
}

#if defined(MESH_STANDARD) || defined(MESH_TWEENED) || defined(MESH_RIGID)
/****************************************************************
		DiffuseBumpSpecularTransRimLight_VS20
 ****************************************************************/
v2fSkinDiffuse DiffuseBumpSpecularTransRimLight_VS20(a2vStandardHQ IN) {
	v2fSkinDiffuse OUT;

	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(IN.v4Position, m44ModelViewProj);

	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,tosigned(IN.v3Tangent),tosigned(IN.v3Binormal),tosigned(IN.v3Normal));
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,IN.v4Position,m33TangentSpace);
	float4 Specular;
	CalculateColorVS(OUT.Diffuse,Specular,IN.vVertexCol);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,IN.v4Position,tosigned(IN.v3Normal));
	//CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
#ifdef PARALLAXENABLED
	CalcParallaxCoords(OUT.vTexCoords,IN.vParallax);
#endif
	
	OUT.EyeVectorOS=normalize(IN.v4Position-v4EyePosObject);

	return OUT;
}

/****************************************************************
		DiffuseBumpSpecularTransRimLight_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularTransRimLight_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLight"; > {
	pass p0 {
		VertexShader=compile vs_3_0 DiffuseBumpSpecularTransRimLight_VS20();
		PixelShader=compile  ps_3_0 DiffuseBumpSpecularTransRimLight_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif

#if defined(MESH_WEIGHTED)
/****************************************************************
		DiffuseBumpSpecularTransRimLightMPS_VS20
 ****************************************************************/
v2fSkinDiffuse DiffuseBumpSpecularTransRimLightMPS_VS20(a2vStandardMPS IN)
{
	v2fSkinDiffuse OUT;
	int4 i=CalcMatrixIndices(IN.v4Indices);
	float4 w=CalcWeights(IN.v4Weights);
	float4 v4PositionOut=Do4MPS(IN.v4Position,i,w);
	float3 v3NormalOut=Do4MPS(tosigned(IN.v3Normal),i,w);
	float3 v3TangentOut=Do4MPS(tosigned(IN.v3Tangent),i,w);
	float3 v3BinormalOut=Do4MPS(tosigned(IN.v3Binormal),i,w);

	//CalcPosition(OUT.Position,IN.v4Position);
	OUT.Position=mul(v4PositionOut, m44ModelViewProj);
	float3x3 m33TangentSpace;
	CalculateTangentSpace(m33TangentSpace,v3TangentOut,v3BinormalOut,v3NormalOut);
	CalculateLightingVS(OUT.LightVector,OUT.HalfVector,OUT.EyeVector.xyz,OUT.LightVectorOS,OUT.TexLightClip,v4PositionOut,m33TangentSpace);
	float4 Specular;
	CalculateColorVS(OUT.Diffuse,Specular,IN.v4Diffuse);
	GetShadowMapVS(OUT.TexShadow,OUT.EyeVector.w,v4PositionOut,v3NormalOut);
	//CalculateFog(OUT.vFog,OUT.Position.xyz);
	
	CalcTextureCoords(OUT.vTexCoords,IN.vTexCoords);
	
	OUT.EyeVectorOS=normalize(v4PositionOut-v4EyePosObject);

	return OUT;
}


/****************************************************************
		DiffuseBumpSpecularTransRimLightMPS_VS20_PS20 
 ****************************************************************/
technique DiffuseBumpSpecularTransRimLightMPS_VS20_PS20 < string Identifier="DiffuseBumpSpecularTransRimLightMPS"; > {
	pass p0 {
		VertexShader=compile vs_3_0  DiffuseBumpSpecularTransRimLightMPS_VS20();
		PixelShader =compile ps_3_0 DiffuseBumpSpecularTransRimLight_PS20();
		
		AlphaBlendEnable=true;
		SrcBlend=SrcAlpha;
		DestBlend=One;
		CullMode=<Culling>;
		ZFunc=Equal;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,1);
	}
}
#endif
