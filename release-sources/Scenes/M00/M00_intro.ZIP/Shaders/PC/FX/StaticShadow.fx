#include "Common.fx"

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

struct a2vStandard {
	float4	v4Position:	POSITION;	
	float4	v4Diffuse:	COLOR0;	
};

struct v2fStandardAmbient10 {
	float4 Position:		POSITION;
	float4 Diffuse:			COLOR0;	
	float vFog:			FOG;
};

// Fragment to surface
struct f2sStandard {
	float4 col:		COLOR0;
};

v2fStandardAmbient10 ShadowDrop_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;		
	
	CalcPosition(OUT.Position,IN.v4Position );						
	// vertex color holds alpha tranparency (1,1,1,alpha), 
	// vStaticShadowColor holds shadow color (r,g,b,1)	
	OUT.Diffuse=IN.v4Diffuse.a*(1-vStaticShadowColor);		
	CalculateFog(OUT.vFog,IN.v4Position.xyz);	
	return OUT;
}

f2sStandard ShadowDrop_PS11(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;		
	OUT.col=IN.Diffuse;	
	return OUT;
}

technique ShadowDrop_VS11_PS11 < string Identifier="ShadowDrop"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ShadowDrop_VS11();
		PixelShader=compile ps_1_1 ShadowDrop_PS11();
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

technique ShadowDrop_VS11_PS00 < string Identifier="ShadowDrop"; > {
	pass p0 {
		VertexShader=compile vs_1_1 ShadowDrop_VS11();
		PixelShader=NULL;
		
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;		
		
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
		AlphaBlendEnable=true;
		SrcBlend=One;
		DestBlend=One;
		AlphaTestEnable=false;
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
v2fStandardAmbient10 ShadowAdd_VS11(a2vStandard IN)
{
	v2fStandardAmbient10 OUT;	
	CalcPosition(OUT.Position,IN.v4Position );						
	// vertex color holds alpha tranparency (1,1,1,alpha), 
	// vStaticShadowColor holds shadow color (r,g,b,1)	
	OUT.Diffuse=IN.v4Diffuse*vStaticShadowColor;		
	CalculateFog(OUT.vFog,IN.v4Position.xyz);	
	return OUT;
}

f2sStandard ShadowAdd_PS11(v2fStandardAmbient10 IN) 
{
	f2sStandard OUT;
	OUT.col=IN.Diffuse;
	return OUT;
}

technique ShadowAdd_VS11_PS11 < string Identifier="ShadowAdd"; > {
	
	pass p0 {
		VertexShader=compile vs_1_1 ShadowAdd_VS11();
		PixelShader=compile ps_1_1 ShadowAdd_PS11();
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}

technique ShadowAdd_VS11_PS00 < string Identifier="ShadowAdd"; > {
	pass p0 {
		VertexShader=compile vs_1_1 ShadowAdd_VS11();
		PixelShader=NULL;
		
		ColorOp[0]=SELECTARG1;
		ColorArg1[0]=DIFFUSE;
		ColorArg2[0]=DIFFUSE;
		ColorOp[1]=DISABLE;		
		
		AlphaOp[0]=SELECTARG1;
		AlphaArg0[0]=DIFFUSE;
		AlphaArg1[0]=DIFFUSE;
		
		TEXTURETRANSFORMFLAGS[0]=0;
		TEXTURETRANSFORMFLAGS[1]=0;
		TEXTURETRANSFORMFLAGS[2]=0;
		TEXTURETRANSFORMFLAGS[3]=0;
		
#ifdef BLENDENABLED
		AlphaBlendEnable=true;
		SrcBlend=<BlendSrc>;
		DestBlend=<BlendDst>;
		AlphaTestEnable=<AlphaTestEnabled>;
		AlphaRef=<AlphaTestValue>;
		AlphaFunc=Greater;
#else
		AlphaBlendEnable=false;
		AlphaTestEnable=false;
#endif
		CullMode=<Culling>;
		ZFunc=LessEqual;
		ZWriteEnable=<gi_iWriteZBuffer>;
		FogEnable=<FogEnabled>;
		FogColor=float4(0,0,0,0);
	}
}